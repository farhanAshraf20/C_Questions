/***********************************************************************
*Row major_Coulumn major
*Farhan Ashraf
*Date:4-feb-2022

************************************************************************/

#include <stdio.h>
int main()
{
	int ba,i,c,r,m,n,j;
	printf("Enter base address :");
	scanf("%d",&ba);
	printf("\nIndex :");
	scanf("%d%d",&i,&j);
	printf("\nEnter Size of one elements :");
	scanf("%d",&c);
	printf("\nEnter total no of rows :");
	printf("\nselect -0 for rows 1 for columns  :");
	scanf("%d",&k);
if(k==0)
{
	printf("\nEnter total no of rows :");
	scanf("%d",&n);
	printf("\n Row major output :%d\n",(ba+(i-1)*m+(j-1))*c);
}
else if(k==1)
{
	printf("\nEnter total no of columns:");
	scanf("%d",&m);
	printf("\n column major output :%d\n",(ba+(j-1)*n+(i-1))*c);
}
else 
{
printf("\ninvalid input\n");
}

return 0;


}