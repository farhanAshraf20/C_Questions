/***********************************************************************
*Polynomial representation using 2d array
*Farhan Ashraf
*Date:4-feb-2022

************************************************************************/

#include<stdio.h>
void main()
{
	int a[10],b[20],r[20],n=0;
	printf("Enter power of x\n");
	scanf("%d",&n);
	printf("Enter value of p(x)\n");
	for(int i=0;i<n;i++)
	{
		printf("x^%d= ",i);
		scanf("%d",&a[i]);
		
	}
	printf("Enter value of q(x)\n");
	for(int i=0;i<n;i++)
	{
		printf("x^%d= ",i);
		scanf("%d",&b[i]);
	}
	printf("p(x) = ");
	
	for(int i=0;i<n;i++)
	{	if(i<(n-1)){
		printf("%dx^%d + ",a[i],i);
		}
		else
	{
		printf("%dx^%d ",a[i],i);
	}
	}
	printf("\nq(x) = ");
	for(int i=0;i<n;i++)
	{	if(i<(n-1)){
		printf("%dx^%d + ",b[i],i);
		}
		else
	{
		printf("%dx^%d ",b[i],i);
	}
	}

	printf("\noutput = ");
	for(int i=0;i<n;i++)
	{
		r[i]=a[i]+b[i];
		if(i<(n-1))
		{
		printf("%dx^%d + ",r[i],i);
		}
		else
		{
		printf("%dx^%d ",r[i],i);
		}
		
	}
		printf("\n");
}