/***********************************************************************
*Linear_vs_sparse
*Farhan Ashraf
*Date:4-feb-2022

************************************************************************/

#include <stdio.h>
int main()
{

	int n,m,nz;
	int l,s;
    
	printf("Enter size of matrix\n");
	printf("enter no of rows\n");
	scanf("%d",&n);
	printf("enter no of columns\n");
	scanf("%d",&m);
    
	printf("Enter no of non-zeroes\n");
	scanf("%d",&nz);
  
	s=m*n;
	l=nz*3;
    
	printf("sparse = %d\nlinear = %d",s,l);
    
	if (s>l)
	    {
		printf("\nliner is better");
	    }
	else
	    {
		printf("\nsparse is better");
	    }

return 0;
}
