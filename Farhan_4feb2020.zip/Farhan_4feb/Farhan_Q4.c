/***********************************************************************
*2d array non_zero value
*Farhan Ashraf
*Date:4-feb-2022

************************************************************************/

#include <stdio.h>    
int main ()    
{   

    int m,n,u,i,j;
    printf("\nEnter rows and columns\n");
    scanf("%d%d",&m,&n);
    m=m+1;
    n=n+1;
    int a[m][n];
    for (i=1;i<m;i++)    
    {    
        for (j=1;j<n;j++)    
        {    
            printf("Enter a[%d][%d]: ",i,j);                
            scanf("%d",&a[i][j]);    
        }    
    }


    printf("\nRow   Cloumn   Value \n");     
 for(i=1;i<m;i++)    
    {   
        for (j=1;j<n;j++)    
        {   
		if(a[i][j]!=0)
		{
   	         printf("%d\t%d\t %d \n",i,j,a[i][j]); 
		}   
        }    
    } 

return 0;   
}