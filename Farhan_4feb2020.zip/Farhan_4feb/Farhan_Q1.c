/***********************************************************************
*1D Array
*Farhan Ashraf
*Date:4-feb-2022

************************************************************************/

#include <stdio.h>
int main()
{
	int ba,i,c,r;
	printf("Enter base address :\n");
	scanf("%d",&ba);
	printf("\nIndex\n");
	scanf("%d",&i);
	printf("\nEnter Size of one elements :\n");
	scanf("%d",&c);

	printf("\noutput :%d",(ba+(i-1)*c));

return 0;


}